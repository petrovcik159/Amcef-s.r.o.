function groupCanceledTransactionsByYear(transactions) {
  return transactions
    .filter(tx => tx.state === 'canceled') // len zrušené
    .sort((a, b) => b.createdAt - a.createdAt) // zoradenie od najnovších
    .reduce((acc, tx) => {
      const year = new Date(tx.createdAt).getFullYear();
      if (!acc[year]) {
        acc[year] = [];
      }
      acc[year].push({
        amount: tx.amount,
        createdAt: tx.createdAt,
        customerName: tx.customerName,
      });
      return acc;
    }, {});
}

